# Cascade v2.3 portrait validation

Brightness statistics are decoded WebP grayscale, expressed from 0 to 100. Warmth means average red exceeds average blue.

| File | Character | Bytes | Q | Mean | SD | Min | Max | Warm |
|---|---|---:|---:|---:|---:|---:|---:|---|
| card-01.webp | Veiled Equinox | 109,324 | 50 | 23.34 | 19.73 | 0.00 | 100.00 | yes |
| card-03.webp | Sunken Oathkeeper | 108,498 | 48 | 21.94 | 17.51 | 0.00 | 100.00 | yes |
| card-05.webp | Gilded Bastion | 92,234 | 68 | 16.80 | 19.64 | 0.00 | 100.00 | yes |
| card-06.webp | Brass Herald | 109,126 | 44 | 23.68 | 21.07 | 0.00 | 100.00 | yes |
| card-08.webp | Stormgrave Empress | 89,068 | 74 | 20.65 | 13.88 | 0.00 | 100.00 | no |
| card-10.webp | Severed Cartographer | 108,076 | 65 | 19.70 | 20.23 | 0.00 | 100.00 | yes |
| card-11.webp | Rimewood Magistrate | 92,028 | 54 | 63.03 | 20.52 | 0.00 | 100.00 | no |
| card-13.webp | Stonefast Warden | 93,050 | 68 | 20.00 | 17.92 | 0.00 | 100.00 | no |
| card-15.webp | Hollow Shepherd | 90,424 | 82 | 25.79 | 18.55 | 3.86 | 100.00 | yes |
| card-17.webp | Pale Cartwright | 90,788 | 68 | 20.73 | 17.58 | 0.67 | 99.83 | yes |
| card-19.webp | Drowned Cantor | 108,406 | 64 | 54.61 | 24.28 | 0.00 | 100.00 | yes |
| card-20.webp | Ashen Ferryman | 98,420 | 68 | 18.53 | 20.47 | 0.00 | 100.00 | no |

Portraits: 12/12. Total: 1,189,442 bytes. Mean range: 16.80–63.03, span 46.23. Warm portraits: 8.

- Tonal target missed: Stormgrave Empress.

Hollow Shepherd is a new design from the commission brief, pending visual approval. Review sheets simulate center-top cover and approximate socket and badge occlusion. Production portraits are image-only.
